﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace POCHTA
{
    public partial class Form4 : Form
    {
        private Form5 F4;
        private Form5 F1;

        public Form4()
        {
            InitializeComponent();
        }

        private void типографияBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.типографияBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.pochtaDataSet1);

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "pochtaDataSet1.Типография". При необходимости она может быть перемещена или удалена.
            this.типографияTableAdapter.Fill(this.pochtaDataSet1.Типография);

        }

        private void button1_Click(object sender, EventArgs e)
        {
            F1 = new Form5();
            F1.Show();
            F4.Close();
        }
    }
}
